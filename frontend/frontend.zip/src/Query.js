import React from 'react'

const Query = ({props}) => {
        return (
            <div className = "articleHeading d-flex justify-content-center text-center">
                {props}
            </div>
          )
    }

export default Query